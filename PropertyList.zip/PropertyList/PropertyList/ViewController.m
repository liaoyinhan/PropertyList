//
//  ViewController.m
//  PropertyList
//
//  Created by liaoyinhan on 13-1-4.
//  Copyright (c) 2013年 liaoyinhan. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITextFieldDelegate>

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //获取Plist文件路径
    NSString *path = [[NSBundle mainBundle] pathForResource:@"MyList" ofType:@"plist"];
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:path];
    NSLog(@"%@",dic);
    //读出内容到用textField里
    self.nameTextField.text = [dic objectForKey:@"name"];
    self.sexTextField.text = [dic objectForKey:@"sex"];
    
}

//点击保存按钮，对所作的更改进行保存
- (IBAction)saveData:(UIButton *)sender
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"MyList" ofType:@"plist"];
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithContentsOfFile:path];
    [dic setObject:self.nameTextField.text forKey:@"name"];
    [dic setObject:self.sexTextField.text forKey:@"sex"];
    //写入
    [dic writeToFile:path atomically:YES];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
