//
//  ViewController.h
//  PropertyList
//
//  Created by liaoyinhan on 13-1-4.
//  Copyright (c) 2013年 liaoyinhan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *sexTextField;

@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
- (IBAction)saveData:(UIButton *)sender;
@end
