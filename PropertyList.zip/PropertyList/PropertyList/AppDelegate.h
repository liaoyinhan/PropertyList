//
//  AppDelegate.h
//  PropertyList
//
//  Created by liaoyinhan on 13-1-4.
//  Copyright (c) 2013年 liaoyinhan. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
